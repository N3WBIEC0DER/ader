from setuptools import setup, Extension

setup(
    name='oth69',
    version='1.0',
    ext_modules=[Extension('oth69', ['oth69.cpython-311.so'])],
)
